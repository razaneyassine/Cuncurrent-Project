package com.company;

import java.util.HashMap;
import java.util.Scanner;

public class Client implements Runnable{
    private HashMap<Company, Float> shares;
    private float balance;
    private StockExchange stockExchange;

    public Client(float balance) {
        this.shares = new HashMap<>();
        this.balance = balance;
    }

    public HashMap<Company,Float> getStocks(){
        return shares;
    }

    public void setStocks(Company company,float numberOfShares){
        shares.put(company,numberOfShares);
    }


    public boolean buy(Company company,float numberOfShares){

     if(numberOfShares < company.getAvailableNumberOfShares()){
         if (!shares.containsKey(company))
             shares.put(company,numberOfShares);
         float t= company.getAvailableNumberOfShares()-numberOfShares;
         company.setAvailableNumberOfShares(t);

        if( this.withdraw(numberOfShares* company.getPrice())) {
            return true;
        }
        else {
            return false;
        }
     }
      return false;
    }

    public boolean sell(Company company, float numberOfShares){
       if(this.deposit(numberOfShares*company.getPrice())){
           if (!shares.containsKey(company))
               shares.put(company,numberOfShares);
           company.setAvailableNumberOfShares(company.getAvailableNumberOfShares()+numberOfShares);
           company.setTotalShares(company.getTotalShares()+numberOfShares);
           return true;
       }
        return false;
    }

    public boolean buyLow(Company company, float numberOfShares, float limit){
        if(company.getPrice()*numberOfShares <= limit)
            return true;
        return false;
    }


    public boolean sellHigh(Company company, float numberOfShares, float limit){
        if(company.getPrice()*numberOfShares >= limit)
            return true;
        return false;
    }


    public boolean deposit(float amount){
        this.balance+=amount;
        System.out.println("Success");
        return true;
    }

    public boolean withdraw(float amount){
        if(amount < this.balance){
            this.balance-=amount;
            System.out.println("Success");
            return true;
        }
        System.out.println("Fail");
        return false;
    }

    public float getBalance() {
        return balance;
    }

    public void setStockExchange(StockExchange stockExchange) {
        this.stockExchange = stockExchange;
    }

    @Override
    public void run() {

        synchronized (this){
            Scanner f=new Scanner(System.in);
            Scanner string=new Scanner(System.in);
            Scanner scanner=new Scanner(System.in);

            System.out.println("Choose for every client the trading process (1:buy- 2:sell), the company name and the number of shares");
            System.out.print("Process Number ");
            int a=f.nextInt();

            System.out.print("Company Name ");
            String s=string.nextLine();

            System.out.print("Number of shares ");
            float share=scanner.nextFloat();

                switch (a){
                    case 1:
                        stockExchange.getCompanies().entrySet().forEach(entry-> {
                            entry.getKey().getName().equals(s);
                            this.buy(entry.getKey(),share);
                        });
                        break;

                    case 2:
                        stockExchange.getCompanies().entrySet().forEach(entry-> {
                            entry.getKey().getName().equals(s);
                            this.sell(entry.getKey(), share);
                        });
                        break;
                }
                System.out.println(this.getBalance());

        }
    }
}
