package com.company;

public class Company {
    private String name;
    private float totalNumberOfShares;
    private float availableNumberOfShares;
    private float price;

    public Company(String name, float totalNumberOfShares, float availableNumberOfShares, float price) {
        this.name = name;
        this.totalNumberOfShares = totalNumberOfShares;
        this.availableNumberOfShares = availableNumberOfShares;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getTotalShares() {
        return totalNumberOfShares;
    }

    public void setTotalShares(float totalNumberOfShares) {
        this.totalNumberOfShares = totalNumberOfShares;
    }

    public float getAvailableNumberOfShares() {
        return availableNumberOfShares;
    }

    public void setAvailableNumberOfShares(float availableNumberOfShares) {
        this.availableNumberOfShares = availableNumberOfShares;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
