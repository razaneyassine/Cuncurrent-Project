package com.company;

import java.util.ArrayList;
import java.util.HashMap;

public class StockExchange {
    static private HashMap<Company,Float> companies;
    private ArrayList<Client> clients;

    public StockExchange( ArrayList<Client> clients) {
        this.companies = new HashMap<>();
        this.clients = clients;
    }


    public boolean registerCompany(Company company,float numberOfShares){
        if(!companies.containsKey(company)){
            companies.put(company,numberOfShares);
            return true;
        }
        return false;
    }

    public boolean deregister(Company company){
        if(companies.containsKey(company)){
            companies.remove(company);
            return true;
        }
        return false;
    }

    public boolean addClient(Client client){
        if(clients.add(client)){
            return true;
        }
        return false;
    }

    public boolean removeClient(Client client){
        if(clients.remove(client))
            return true;
        return false;
    }

    public ArrayList<Client> getClients(){
        return clients;
    }

    public HashMap<Company, Float> getCompanies() {
        return companies;
    }

    public void setPrice(Company company,float price){
        if(price > 0){
                company.setPrice(price);
        }
    }

    public void changePriceBy(Company company,float price){
       float temp=company.getPrice();
        if(temp+price >0){
            company.setPrice(temp+price);
        }

    }
}
