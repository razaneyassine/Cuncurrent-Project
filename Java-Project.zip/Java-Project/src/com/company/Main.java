package com.company;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws InterruptedException {
	// write your code here

        Scanner scanner=new Scanner(System.in);
        Scanner f=new Scanner(System.in);
        Scanner string=new Scanner(System.in);
        Company company1=new Company("Company A", (float)50.0,(float) 26.3,(float)500);
        company1.setPrice(39);
        Company company2=new Company("Company B", (float)50.0, (float)26.3,(float)500);
        company2.setPrice(43);
        Company company3=new Company("Company C", (float)50.0, (float)26.3,(float)500);
        company3.setPrice(65);
        Company company4=new Company("Company D", (float)50.0,(float) 26.3,(float)500);
        company4.setPrice(35);

        Client client1=new Client((float) 852.8);
        Client client2=new Client((float)1569.0);
        Client client3=new Client((float)3587.5);

        ArrayList<Client> clients=new ArrayList<>();
        clients.add(client1);
        clients.add(client2);
        clients.add(client3);

        StockExchange stockExchange=new StockExchange(clients);


        client1.setStockExchange(stockExchange);
        client2.setStockExchange(stockExchange);
        client3.setStockExchange(stockExchange);

        stockExchange.addClient(client1);
        stockExchange.addClient(client2);
        stockExchange.addClient(client3);

        stockExchange.registerCompany(company1,3);
        stockExchange.registerCompany(company2,2);
        stockExchange.registerCompany(company3,1);
        stockExchange.registerCompany(company4,6);
        int n=1;
        int operation;
        do{
            System.out.println("Choose your operation: \n" +
                    "1-Get All Clients \n" +
                    "2-Get All Companies \n" +
                    "3-Register Company \n" +
                    "4-Deregister Company \n" +
                    "5-Add Client \n" +
                    "6-Remove Client \n" +
                    "7-Set Price for Company \n" +
                    "8-Change Price By for Company \n" +
                    "9-Start Trading Share" );
            operation=scanner.nextInt();

            switch (operation){
                case 1: ArrayList<Client> c=stockExchange.getClients();
                        for (int i=0;i<c.size();i++){
                            System.out.println("Client "+i+""+c.get(i).getBalance());
                        }
                        break;
                case 2:
                    HashMap<Company,Float> c1=stockExchange.getCompanies();
                    c1.entrySet().forEach(entry->{
                        System.out.println(entry.getKey().getName()+" "+entry.getValue());
                    });

                        break;
                case 3:
                    System.out.println("Enter the name of the Company");
                    String name =scanner.next();
                    System.out.println("Enter the Total Number");
                    float total=f.nextFloat();
                    System.out.println("Enter the available number of shares");
                    float available=f.nextFloat();
                    System.out.println("Enter the price");
                    float price=f.nextFloat();
                    System.out.println("Enter the number of shares");
                    float number=f.nextFloat();
                    Company company=new Company(name,total,available,price);
                    stockExchange.registerCompany(company,number);
                    break;

                case 4:
                    System.out.println("Enter the name of the company to be removed");
                    String remove=scanner.next();
                    stockExchange.getCompanies().entrySet().forEach(entry->{
                        entry.getKey().getName().equals(remove);
                        stockExchange.deregister(entry.getKey());
                    });


                case 5:
                    System.out.println("Enter the balance of the client");
                    float balance=scanner.nextFloat();
                    Client client=new Client(balance);
                    stockExchange.addClient(client);
                    client.setStockExchange(stockExchange);
                    break;

                case 6:
                    ArrayList<Client> c2=stockExchange.getClients();
                    System.out.println("Choose the number of the client you want to remove");
                    for (int i=0;i<c2.size();i++){
                        System.out.println("Client "+i+""+c2.get(i).getBalance());
                    }
                    int j=scanner.nextInt();
                    c2.remove(j);
                    break;

                case 7:
                    System.out.println("Enter the Company Name and the Price");
                    String cname=scanner.next();
                    float newPrice=f.nextFloat();
                    stockExchange.getCompanies().entrySet().forEach(entry->{
                          entry.getKey().getName().equals(cname);
                          stockExchange.setPrice(entry.getKey(),newPrice);
                    });
                    break;

                case 8:
                    System.out.println("Enter the name of the company and value to be changed by");
                    String cn=scanner.next();
                    float change=f.nextFloat();
                    stockExchange.getCompanies().entrySet().forEach(entry->{
                        entry.getKey().getName().equals(cn);
                        stockExchange.changePriceBy(entry.getKey(),change);
                    });
                    break;
                case 9:
                    System.out.println("How Many Clients do you want to trade (max number" + stockExchange.getClients().size()+ ")");
                    int tradeNumber=scanner.nextInt();
                    System.out.println("Choose the clients' ids to start trading");
                    for (int i=0;i<stockExchange.getClients().size();i++){
                        System.out.println("Client "+i+""+stockExchange.getClients().get(i).getBalance());
                    }

                    ArrayList<Client>tradingClients=new ArrayList<>();

                    int id;
                    for (int i=0;i<tradeNumber;i++){
                        id=scanner.nextInt();
                    if(id<= stockExchange.getClients().size()){
                        tradingClients.add(stockExchange.getClients().get(id));
                    }
                    }


                    for (int i =0;i< tradingClients.size();i++){
                         Thread thread= new Thread(tradingClients.get(i));
                            thread.start();
                             thread.join();
                    }




                break;

            }
            System.out.println("Do you want to continue(1 yes)");
            n=scanner.nextInt();
        }while (n==1);


    }
}
